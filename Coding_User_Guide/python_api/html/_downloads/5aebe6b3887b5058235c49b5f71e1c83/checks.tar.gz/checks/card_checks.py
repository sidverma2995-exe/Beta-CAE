import ansa
from ansa import constants
from ansa import base

def check_properties(entity:base.Entity, card_fields:dict, *args, **kwargs) -> dict:

	nip = card_fields['N']
	thick = card_fields['THICK']

	is_error = False
	if thick < 1. and nip != 3:
		is_error = True
	elif thick >= 1. and nip != 5:
		is_error = True

	if is_error:
		mes = "NIP parameter should respect 'If thickness<1mm then NIP=3 else NIP=5'"
	else:
		mes = None

	ret_dict = {'message': mes, 'error_fields': ('N',), 'error': is_error}
	return ret_dict

def check_inters(cnctn:base.Entity, card_fields:dict) -> dict:
	
	ret_dict = {'message': None, 'error_fields': ('ISTF',), 'error': False}
	if card_fields['TYPE'] != 'TYPE7':
		return ret_dict

	istf = card_fields['ISTF']

	if istf != '0' and istf != '4':
		eid = card_fields['EID']
		name = card_fields['Name']
		ret_dict['message'] = '/INTER/TYPE7 %d %s: The ISTF parameter must be set to 0 or 4' % (eid, name)
    
	return ret_dict
