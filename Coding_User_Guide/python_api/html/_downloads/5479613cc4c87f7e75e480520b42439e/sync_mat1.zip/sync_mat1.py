"""
This tool translates Nastran MATT1 material tabular data (T(E)_T1 and T(NU)_T1) to Abaqus Isotropic.
"""

from ansa import base
from ansa import constants

def _get_values_from_source_mat(source_mat: base.Entity, data: list, verbose: bool) -> bool:
    if not base.GetEntityType(constants.NASTRAN, source_mat):
        if verbose: print('NASTRAN MAT1 is needed!')
        return False
    
    fields = ('MATT1', 'E', 'T(E)_T1', 'NU', 'T(NU)_T1')
    ret_fields = base.GetEntityCardValues(constants.NASTRAN, source_mat, fields)
    
    if ret_fields['MATT1'].strip() == 'NO':
        if verbose: print('Temperature dependency not defined (MATT1).')
        return False
    
    if ret_fields['T(E)_T1']:
        ent = base.GetEntity(constants.NASTRAN, 'TABLEM', ret_fields['T(E)_T1'])
        _read_tablem_nas(ent, data)
    elif ret_fields['E']:
        data.append(ret_fields['E'])
    else:
        return False
    
    if ret_fields['T(NU)_T1']:
        ent = base.GetEntity(constants.NASTRAN, 'TABLEM', ret_fields['T(NU)_T1'])
        _read_tablem_nas(ent, data)
    elif ret_fields['NU']:
        data.append(ret_fields['NU'])
    else:
        return False
    
    return True

def _read_tablem_nas(ent: base.Entity, data: list) -> None:
    curve_data = base.GetLoadCurveData(ent)
    data.append(curve_data) 

def _set_values_to_target_mat(source_mat: base.Entity, target_mat: base.Entity, data: list, verbose: bool) -> bool:
    """Setup the ABAQUS Isotropic material"""
    if not base.GetEntityType(constants.ABAQUS, target_mat):
        if verbose: print('ABAQUS MATERIAL is needed!')
        return False
    
    if not isinstance(data[0], list):
        if verbose: print('No TABLEM found in T(E)_T1 field.')
        return False
    
    # Write elasticity
    abqt_data = []
    for i in range(0, len(data[0])):
        temp = []
        for j in range(0, 2):
            if isinstance(data[j], list):
                temp.append(data[j][i][1])
            else:
                temp.append(data[j])
        
        temp.append(data[0][i][0])
        abqt_data.append(temp)
    
    eltab = base.CreateLoadCurve('DEPENDENCY_DATA_TABLE', {})
    base.SetLoadCurveData(eltab, abqt_data)
    
    dt = eltab.get_entity_values(constants.ABAQUS, ('DID',))['DID']
    mat_vals = {'Name': source_mat._name,
                '*ELASTIC': 'YES',
                'ELASTIC_TYPE': 'ISOTROPIC',
                'DEP_ELAST': 'YES',
                'DATA TABLE ELAST': dt}
    
    target_mat.set_entity_values(constants.ABAQUS, mat_vals)

def sync(source_mat: base.Entity, target_mat: base.Entity, *args, **kwargs) -> None:
    data = []
    verbose = False
    status = _get_values_from_source_mat(source_mat, data, verbose)
    if status:
        _set_values_to_target_mat(source_mat, target_mat, data, verbose)
    else:
        if verbose: print('Material could not be translated!')
