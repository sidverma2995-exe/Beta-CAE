#include <stdio.h>

#include "udc.h"


/* -------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------- */
static void external_product(double dx1, double dy1, double dz1, double dx2, double dy2, double dz2,
		double *dx, double *dy, double *dz)
{
	*dx = (dy1 * dz2) - (dz1 * dy2);
	*dy = (dz1 * dx2) - (dx1 * dz2);
	*dz = (dx1 * dy2) - (dy1 * dx2);
} /* external_product */


/* -------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------- */
static double tetra_volume(double x1, double y1, double z1,
		double x2, double y2, double z2,
		double x3, double y3, double z3,
		double x, double y, double z)
{
	double dx1, dy1, dz1;
	double dx2, dy2, dz2;
	double dx3, dy3, dz3;
	double dx, dy, dz;
	double volume;

	dx1 = x1 - x;
	dy1 = y1 - y;
	dz1 = z1 - z;
	dx2 = x2 - x;
	dy2 = y2 - y;
	dz2 = z2 - z;
	dx3 = x3 - x;
	dy3 = y3 - y;
	dz3 = z3 - z;

	external_product(dx1, dy1, dz1, dx2, dy2, dz2, &dx, &dy, &dz);

	volume = dx*dx3 + dy*dy3 + dz*dz3;

	return 1.6666666666666666666E-01 * volume;
} /* tetra_volume */


/* -------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------- */
static double tetra_volume_by_nodes(void *n1, void *n2, void *n3, void *n4)
{
	double volume;
	double pos1[3] = { 0.0 };
	double pos2[3] = { 0.0 };
	double pos3[3] = { 0.0 };
	double pos4[3] = { 0.0 };

	betaudc_a_ent_node_pos(n1, pos1);
	betaudc_a_ent_node_pos(n2, pos2);
	betaudc_a_ent_node_pos(n3, pos3);
	betaudc_a_ent_node_pos(n4, pos4);

	volume = tetra_volume(pos1[0], pos1[1], pos1[2],
			pos2[0], pos2[1], pos2[2],
			pos3[0], pos3[1], pos3[2],
			pos4[0], pos4[1], pos4[2]);
	return volume;
} /* tetra_volume_by_nodes */


/* -------------------------------------------------------------------------------------------------------- */

/* -------------------------------------------------------------------------------------------------------- */
/*!
 * \fn int udc_solid_volume(void *solid, double *value)
 * \brief Calculates the volume of a 1st order solid element
 *
 * \param solid the solid element to be used for the calculation
 * \param *value the calculated value
 * \return 1 if a value has been calculated, 0 otherwise
 */
int udc_solid_volume(void *solid, double *value)
{
	int nodes_num = 0;
	double volume = 0.0;
	void *nodes[8] = { NULL };
	UdcElementType type = UDC_UNKNOWN;

	if (!betaudc_a_ent_is_solid(solid)) return 0;

	nodes_num = betaudc_a_ent_solid_nodes(solid, nodes);

	if (!nodes_num) return 0;

	type = betaudc_a_ent_get_element_type(solid);

	switch (type) {
		case UDC_CTETRA:
			volume = tetra_volume_by_nodes(nodes[1], nodes[0], nodes[2], nodes[3]);
			break;
		case UDC_PYRAMID:
			volume += tetra_volume_by_nodes(nodes[0], nodes[2], nodes[1], nodes[4]);
			volume += tetra_volume_by_nodes(nodes[2], nodes[0], nodes[3], nodes[4]);
			break;
		case UDC_CPENTA:
			volume += tetra_volume_by_nodes(nodes[0], nodes[2], nodes[1], nodes[3]);
			volume += tetra_volume_by_nodes(nodes[3], nodes[4], nodes[5], nodes[1]);
			volume += tetra_volume_by_nodes(nodes[3], nodes[5], nodes[2], nodes[1]);
			break;
		case UDC_CHEXA:
			volume += tetra_volume_by_nodes(nodes[0], nodes[2], nodes[1], nodes[5]);
			volume += tetra_volume_by_nodes(nodes[0], nodes[5], nodes[4], nodes[2]);
			volume += tetra_volume_by_nodes(nodes[2], nodes[6], nodes[5], nodes[4]);

			volume += tetra_volume_by_nodes(nodes[0], nodes[3], nodes[2], nodes[7]);
			volume += tetra_volume_by_nodes(nodes[0], nodes[7], nodes[2], nodes[4]);
			volume += tetra_volume_by_nodes(nodes[2], nodes[6], nodes[4], nodes[7]);
			break;
		default:
			return 0;
	}

	*value = volume;

	return 1;
} /* udc_solid_volume */
