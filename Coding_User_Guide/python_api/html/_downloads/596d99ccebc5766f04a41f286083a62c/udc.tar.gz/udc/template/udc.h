#ifndef _UDC_H_
#define _UDC_H_


#ifdef WIN32
#define DLL_PUBLIC __declspec(dllexport)
#define DLL_IMPORT __declspec(dllimport)
#endif

#if __GNUC__ >= 4
#define DLL_PUBLIC __attribute__ ((visibility("default")))
#define DLL_IMPORT
#endif

#ifndef DLL_PUBLIC
#define DLL_PUBLIC
#endif

#ifndef DLL_IMPORT
#define DLL_IMPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif
        typedef enum UdcElementType {
		UDC_UNKNOWN    =  0,
		UDC_NODE       =  1,
		UDC_CQUAD4     =  6,
		UDC_CTRIA3     =  7,
		UDC_CQUAD8     =  8,
		UDC_CTRIA6     =  9,
		UDC_CTETRA     = 20,
		UDC_PYRAMID    = 21,
		UDC_CPENTA     = 22,
		UDC_CHEXA      = 23,
		UDC_CTETRA2    = 24,
		UDC_PYRAMID2   = 25,
		UDC_CPENTA2    = 26,
		UDC_CHEXA2     = 27,
		UDC_POLYGON    = 30,
		UDC_POLYHEDRON = 31
        } UdcElementType;


	/* User Defined Quality Criteria Functions */

	/*!
	 * \fn int udc_solid_volume(void *solid, double *value)
	 * \brief Example function which calculates the volume of a 1st order solid element
	 *
	 * \param solid the solid element to be used for the calculation
	 * \param value the calculated value
	 * \return 1 if a value has been calculated, 0 otherwise
	 */
	extern DLL_PUBLIC int udc_solid_volume(void *solid, double *value);

	/* ~User Defined Quality Criteria Functions */


	/* User Defined Calculations API Functions */

	/*!
	 * \fn int betaudc_a_ent_is_node(void *element)
	 * \brief check if element is a NODE
	 *
	 * \param element the element to be checked
	 * \return 1 if element is a NODE, 0 otherwise
	 */
	extern DLL_IMPORT int betaudc_a_ent_is_node(void *element);

	/*!
	 * \fn int betaudc_a_ent_is_shell(void *element)
	 * \brief check if element is a SHELL
	 *
	 * \param element the element to be checked
	 * \return 1 if element is a SHELL, 0 otherwise
	 */
	extern DLL_IMPORT int betaudc_a_ent_is_shell(void *element);

	/*!
	 * \fn int betaudc_a_ent_is_polygon(void *element)
	 * \brief check if element is a POLYGON
	 *
	 * \param element the element to be checked
	 * \return 1 if element is a POLYGON, 0 otherwise
	 */
	extern DLL_IMPORT int betaudc_a_ent_is_polygon(void *element);

	/*!
	 * \fn int betaudc_a_ent_is_solid(void *element)
	 * \brief check if element is a SOLID
	 *
	 * \param element the element to be checked
	 * \return 1 if element is a SOLID, 0 otherwise
	 */
	extern DLL_IMPORT int betaudc_a_ent_is_solid(void *element);

	/*!
	 * \fn int betaudc_a_ent_is_polyhedron(void *element)
	 * \brief check if element is a POLYHEDRON
	 *
	 * \param element the element to be checked
	 * \return 1 if element is a POLYHEDRON, 0 otherwise
	 */
	extern DLL_IMPORT int betaudc_a_ent_is_polyhedron(void *element);

	/*!
	 * \fn int betaudc_a_ent_get_element_type(void *element)
	 * \brief get the UdcElementType of the element
	 *
	 * \param element the element to get its UdcElementType
	 * \return the UdcElementType
	 */
	extern DLL_IMPORT int betaudc_a_ent_get_element_type(void *element);

	/*!
	 * \fn int betaudc_a_ent_node_pos(void *node, double *pos)
	 * \brief get the coordinates of a NODE
	 *
	 * \param node the NODE to get its coordinates
	 * \param pos a 3 doubles array with the x, y, z coordinates
	 * \return always returns 0
	 */
	extern DLL_IMPORT int betaudc_a_ent_node_pos(void *node, double *pos);

	/*!
	 * \fn int betaudc_a_ent_shell_nodes(void *shell, void *nodes[4])
	 * \brief get the 1st order NODEs of a SHELL. a node might be NULL
	 *
	 * \param shell the SHELL to get its NODEs
	 * \param nodes an array with the SHELL NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_shell_nodes(void *shell, void *nodes[4]);

	/*!
	 * \fn int betaudc_a_ent_shell_nodes_2nd_order(void *shell, void *nodes[8])
	 * \brief get the 2nd order NODEs of a SHELL. a node might be NULL
	 *
	 * \param shell the SHELL to get its NODEs
	 * \param nodes an array with the SHELL NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_shell_nodes_2nd_order(void *shell, void *nodes[8]);

	/*!
	 * \fn int betaudc_a_ent_shell_nodes_num(void *shell)
	 * \brief get the number of the 1st order NODEs of a SHELL
	 *
	 * \param shell the SHELL to get its NODEs number
	 * \return the number of the 1st order NODEs of a SHELL
	 */
	extern DLL_IMPORT int betaudc_a_ent_shell_nodes_num(void *shell);

	/*!
	 * \fn int betaudc_a_ent_shell_nodes_num_2nd_order(void *shell)
	 * \brief get the number of the 2nd order NODEs of a SHELL
	 *
	 * \param shell the SHELL to get its NODEs number
	 * \return the number of the 2nd order NODEs of a SHELL
	 */
	extern DLL_IMPORT int betaudc_a_ent_shell_nodes_num_2nd_order(void *shell);

	/*!
	 * \fn int betaudc_a_ent_polygon_nodes(void *polygon, void **nodes)
	 * \brief get the NODEs of a POLYGON
	 *
	 * \param polygon the POLYGON to get its NODEs
	 * \param nodes an array with the POLYGON NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_polygon_nodes(void *polygon, void **nodes);

	/*!
	 * \fn int betaudc_a_ent_polygon_nodes_num(void *polygon)
	 * \brief get the number of NODEs of a POLYGON
	 *
	 * \param polygon the POLYGON to get its NODEs number
	 * \return the number of NODEs of a POLYGON
	 */
	extern DLL_IMPORT int betaudc_a_ent_polygon_nodes_num(void *polygon);

	/*!
	 * \fn int betaudc_a_ent_solid_nodes(void *solid, void *nodes[8])
	 * \brief get the 1st order NODEs of a SOLID. a node might be NULL
	 *
	 * \param solid the SOLID to get its NODEs
	 * \param nodes an array with the SOLID NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_nodes(void *solid, void *nodes[8]);

	/*!
	 * \fn int betaudc_a_ent_solid_nodes_2nd_order(void *solid, void *nodes[20])
	 * \brief get the 2nd order NODEs of a SOLID. a node might be NULL
	 *
	 * \param solid the SOLID to get its NODEs
	 * \param nodes an array with the SOLID NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_nodes_2nd_order(void *solid, void *nodes[20]);

	/*!
	 * \fn int betaudc_a_ent_solid_nodes_num(void *solid)
	 * \brief get the number of the 1st order NODEs of a SOLID
	 *
	 * \param solid the SOLID to get its NODEs number
	 * \return the number of the 1st order NODEs of a SOLID
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_nodes_num(void *solid);

	/*!
	 * \fn int betaudc_a_ent_solid_nodes_num_2nd_order(void *solid)
	 * \brief get the number of the 2nd order NODEs of a SOLID
	 *
	 * \param solid the SOLID to get its NODEs number
	 * \return the number of the 2nd order NODEs of a SOLID
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_nodes_num_2nd_order(void *solid);

	/*!
	 * \fn int betaudc_a_ent_polyhedron_nodes(void *polyhedron, void **nodes)
	 * \brief get the NODEs of a POLYHEDRON
	 *
	 * \param polyedron the POLYHEDRON to get its NODEs
	 * \param nodes an array with the unique POLYHEDRON NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_polyhedron_nodes(void *polyhedron, void **nodes);

	/*!
	 * \fn int betaudc_a_ent_polyhedron_nodes_num(void *polyhedron)
	 * \brief get the number of NODEs of a POLYHEDRON
	 *
	 * \param polyedron the POLYHEDRON to get its NODEs number
	 * \return the number of the NODEs of a POLYHEDRON
	 */
	extern DLL_IMPORT int betaudc_a_ent_polyhedron_nodes_num(void *polyhedron);

	/*!
	 * \fn int betaudc_a_ent_solid_facets(void *solid, void *nodes[6][4])
	 * \brief get the 1st order NODEs of the facets of a SOLID. a node might be NULL
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param nodes a 6x4 array with the SOLID facet NODEs
	 * \return the number of SOLID facets
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facets(void *solid, void *nodes[6][4]);

	/*!
	 * \fn int betaudc_a_ent_solid_facets_2nd_order(void *solid, void *nodes[6][8])
	 * \brief get the 2nd order NODEs of the facets of a SOLID. a node might be NULL
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param nodes a 6x8 array with the SOLID facet NODEs
	 * \return the number of SOLID facets
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facets_2nd_order(void *solid, void *nodes[6][8]);

	/*!
	 * \fn int betaudc_a_ent_solid_facets_num(void *solid)
	 * \brief get number of the facets of a SOLID
	 *
	 * \param solid the SOLID to get its facets number
	 * \return the number of SOLID facets
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facets_num(void *solid);

	/*!
	 * \fn int betaudc_a_ent_solid_facet_nodes(void *solid, int facet, void *nodes[4])
	 * \brief get the 1st order NODEs of a SOLID facet. a node might be NULL
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param facet the SOLID facet index
	 * \param nodes an array with the SOLID facet NODEs
	 * \return the number of facet NODEs
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facet_nodes(void *solid, int facet, void *nodes[4]);

	/*!
	 * \fn int betaudc_a_ent_solid_facet_nodes_2nd_order(void *solid, int facet, void *nodes[8])
	 * \brief get the 2nd order NODEs of a SOLID facet. a node might be NULL
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param facet the SOLID facet index
	 * \param nodes an array with the SOLID facet NODEs
	 * \return the number of facet NODEs
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facet_nodes_2nd_order(void *solid, int facet, void *nodes[8]);

	/*!
	 * \fn int betaudc_a_ent_solid_facet_nodes_num(void *solid, int facet)
	 * \brief get the number of the 1st order NODEs of a SOLID facet
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param facet the SOLID facet index
	 * \return the number of facet NODEs
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facet_nodes_num(void *solid, int facet);

	/*!
	 * \fn int betaudc_a_ent_solid_facet_nodes_num_2nd_order(void *solid, int facet)
	 * \brief get the number of the 2nd order NODEs of a SOLID facet
	 *
	 * \param solid the SOLID to get its facet NODEs
	 * \param facet the SOLID facet index
	 * \return the number of facet NODEs
	 */
	extern DLL_IMPORT int betaudc_a_ent_solid_facet_nodes_num_2nd_order(void *solid, int facet);

	/*!
	 * \fn int betaudc_a_ent_polyhedron_hedra_nodes(void *polyhedron, int hedra, void **nodes)
	 * \brief get the NODEs of a POLYHEDRON hedra
	 *
	 * \param polyedron the POLYHEDRON to get its hedra NODEs
	 * \param hedra the POLYHEDRON hedra index
	 * \param nodes an array with the POLYHEDRON hedra NODEs
	 * \return the number of NODEs in the nodes array
	 */
	extern DLL_IMPORT int betaudc_a_ent_polyhedron_hedra_nodes(void *polyhedron, int hedra, void **nodes);

	/*!
	 * \fn int betaudc_a_ent_polyhedron_hedra_nodes_num(void *polyhedron, int hedra)
	 * \brief get the number of NODEs of a POLYHEDRON hedra
	 *
	 * \param polyedron the POLYHEDRON to get its hedra NODEs
	 * \param hedra the POLYHEDRON hedra index
	 * \return the number of the hedra NODEs
	 */
	extern DLL_IMPORT int betaudc_a_ent_polyhedron_hedra_nodes_num(void *polyhedron, int hedra);

	/*!
	 * \fn int betaudc_a_ent_polyhedron_hedras_num(void *polyhedron)
	 * \brief get the number of hedras of a POLYHEDRON
	 *
	 * \param polyedron the POLYHEDRON to get its number of hedras
	 * \return the number of the POLYHEDRON hedras
	 */
	extern DLL_IMPORT int betaudc_a_ent_polyhedron_hedras_num(void *polyhedron);

	/* ~User Defined Calculations API Functions */

#ifdef __cplusplus
}
#endif

#endif
