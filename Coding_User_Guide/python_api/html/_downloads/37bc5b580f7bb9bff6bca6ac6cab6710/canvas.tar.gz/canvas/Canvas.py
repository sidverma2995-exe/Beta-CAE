import ansa
from ansa import base

def main():
	canvas = base.Canvas('MyCanvas')

	# Points
	canvas.set_color(0xFF0000FF)
	canvas.point_size(10)
	canvas.point(0, 0, -1)
	canvas.point(1, 0, -1, 'square_hollow')
	canvas.point(2, 0, -1, 'circle')
	canvas.point(3, 0, -1, 'circle_hollow')
	canvas.point(4, 0, -1, 'diamond')
	canvas.point(5, 0, -1, 'diamond_hollow')
	canvas.point(6, 0, -1, 'hexa_hollow')
	canvas.point(7, 0, -1, 'cross')

	# Lines
	canvas.set_color(0xFF0000FF)
	canvas.line((0, 0, 0), (1, 0, 0))
	canvas.line_width(2)
	canvas.stippled_line((0, 0, 1), (1, 0, 1))

	# Arrows
	canvas.set_color(0x00FF00FF)
	canvas.arrow((2, 0, 2), (2, 1, 2))
	canvas.arrow((3, 0, 2), (3, 1, 2), type=1)
	canvas.arrow((4, 0, 2), (4, 1, 2), type=2)
	canvas.arrow((5, 0, 2), (5, 1, 2), line_width=2, size_of_tip=0.25, pos_of_tip=0.6, type=0)

	# Shapes 2D
	canvas.set_color(0x0000FFFF)
	canvas.triangle((0, 0, 7), (1, 0, 7), (0.5, 1, 7))
	canvas.triangle((4, 0, 7), (5, 0, 7), (4.5, 1, 7), False)
	canvas.quad((2, 0, 7), (3, 0, 7), (3, 1, 7), (2, 1, 7))
	canvas.quad((6, 0, 7), (7, 0, 7), (7, 1, 7), (6, 1, 7), False)

	# Shapes 3D
	canvas.set_color(0x0000FFFF)
	canvas.sphere((0, 0, 5), 0.5)
	canvas.sphere((5, 0, 5), 0.5, False)
	canvas.cylinder((1.5, 0, 5), (0, 1, 0), 0.5, 1)
	canvas.cylinder((6.5, 0, 5), (0, 1, 0), 0.5, 1, False)
	canvas.cube((3, 0, 4.5), (4, 0, 4.5), (4, 1, 4.5), (3, 1, 4.5), (3, 0, 5.5), (4, 0, 5.5), (4, 1, 5.5), (3, 1, 5.5))
	canvas.cube((8, 0, 4.5), (9, 0, 4.5), (9, 1, 4.5), (8, 1, 4.5), (8, 0, 5.5), (9, 0, 5.5), (9, 1, 5.5), (8, 1, 5.5), False)

	# Symbols
	canvas.set_color(0xFF00FFFF)
	canvas.symbol_origin(5, 0, 0)
	canvas.symbol_line((5, 0, 1), (6, 0, 1))
	canvas.symbol_triangle((7, 0, 1), (8, 0, 1), (7.5, 0, 2))
	canvas.symbol_cone((9, 0, 1), (10, 0, 1), 0.5)
	canvas.symbol_label((5, 0, 0), 'Symbols')

	canvas.show()
#	canvas.hide()
#	canvas.clear()
#	canvas.delete()

	names = base.CanvasList()
	for name in names:
		print(name)
		canvas = base.Canvas(name)
		print(canvas._name)

if __name__ == '__main__':
	main()
