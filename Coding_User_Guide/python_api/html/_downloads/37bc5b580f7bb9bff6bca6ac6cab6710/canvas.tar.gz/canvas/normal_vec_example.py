import ansa
from ansa import base
from ansa import constants

def _shell_norm_in_canvas(canvas, elem):
	n_vec = base.GetNormalVectorOfShell(elem)
	tail = base.Cog(elem)
	head = (tail[0] + 2*n_vec[0], tail[1] + 2*n_vec[1], tail[2] + 2*n_vec[2])
	canvas.arrow(tail, head)
	canvas.label(head , 'Normal vector of elem %d' % (elem._id, ))

def _shell_cog_in_canvas(canvas, elem):
	cog = base.Cog(elem)
	canvas.point(cog[0], cog[1], cog[2], 'circle_hollow')

def _wait_for_middle(text):
	print(text)
	base.PickEntities(constants.ABAQUS, 'SHELL')

def main():
	elem = base.PickEntities(constants.ABAQUS, 'SHELL')[0]
    
	canvas = base.Canvas('MyCanvas')
  	canvas.set_color(0x00FF00FF)
	_shell_norm_in_canvas(canvas, elem)
	canvas.show()

	_wait_for_middle("Press middle to draw cog on elements")
	vals = elem.get_entity_values(constants.ABAQUS, ('__prop__', ))
	prop = vals['__prop__']
	elems = base.CollectEntities(constants.ABAQUS, prop, "SHELL", recursive=True)

	canvas.delete()
	canvas = base.Canvas('MyCanvasProp')
	canvas.set_color(0xFF0000FF)
	for elem in elems:
		_shell_cog_in_canvas(canvas, elem)

	_wait_for_middle("Press middle to draw arrows on the whole property")
	canvas.delete()
	canvas = base.Canvas('MyCanvasProp')
	canvas.set_color(0xFF0000FF)
	for elem in elems:
		_shell_norm_in_canvas(canvas, elem)
	canvas.show()
    
	_wait_for_middle("Press middle to destroy the Canvas Draw")

	canvas.delete()
	base.RedrawAll()

if __name__ == '__main__':
	main()
