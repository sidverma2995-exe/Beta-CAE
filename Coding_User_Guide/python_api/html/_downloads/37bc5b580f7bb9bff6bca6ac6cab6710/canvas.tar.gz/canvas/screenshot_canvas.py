def foo():
	canvas = base.Canvas('MyCanvas')

	canvas.set_color(0xFF0000FF)
	canvas.point_size(10)
	canvas.point(0, 0, -1)
	canvas.point(2, 0, -1, 'circle')

	canvas.label((8, 0, -1), 'Label')

	canvas.line_width(2)
	canvas.line((0, 0, 0), (1, 0, 0))
	canvas.stippled_line((0, 0, 1), (1, 0, 1))

	canvas.arrow((2, 0, 2), (2, 1, 2))

	canvas.triangle((0, 0, 7), (1, 0, 7), (0.5, 1, 7))
	canvas.quad((2, 0, 7), (3, 0, 7), (3, 1, 7), (2, 1, 7))

	canvas.sphere((0, 0, 5), 0.5)
	canvas.cylinder((1.5, 0, 5), (0, 1, 0), 0.5, 1)
	canvas.cube((3, 0, 4.5), (4, 0, 4.5), (4, 1, 4.5), (3, 1, 4.5), (3, 0, 5.5), (4, 0, 5.5), (4, 1, 5.5), (3, 1, 5.5))
