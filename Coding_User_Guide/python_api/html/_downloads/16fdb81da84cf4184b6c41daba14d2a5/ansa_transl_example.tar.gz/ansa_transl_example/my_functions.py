import ansa

@ansa.session.defbutton('Planets', 'Earth')
def test_earth():
	
	print('Hello Earth')
	return 0

@ansa.session.defbutton('Planets', 'Mars')
def test_mars():

	print('Hello Mars')
	return 0
