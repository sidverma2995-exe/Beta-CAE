import sys
import ansa
from ansa import betascript

#----------Load Python Scripts---------

sys.path.append('./')
import my_functions


#-------Load Python Obfuscated---------

ansa.ImportCode('./my_binary_functions.pyb')


#-------Load Legacy Betascripts--------

@ansa.session.defbutton('BETA Scripts', 'Pluto')
def my_bs_function():
    betascript.LoadExecuteFunc('MyBSFunction.bs', 'main')

