import ansa
from ansa import base
from ansa import constants

def main():
    actions_callback_file = './AddListActionCallback.py'

    # Add action in PROPERTY list in ABAQUS deck
    base.AddListAction(action_name='User Action', deck=constants.ABAQUS, keyword='PROPERTY',
                        filename=actions_callback_file, function_name='action',
                        separator=True)
    
    # Add action in LAMINATE list in ABAQUS deck
    base.AddListAction(action_name='User Action 1', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action')

    # Add action in LAMINATE list in all decks
    base.AddListAction(action_name='User Action 2', deck=constants.decks, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action')

    # Add action in DISLOADS TEMPFILM (subtype) in PERMAS deck and FILM in ABAQUS deck
    base.AddListAction(action_name='User Action 3', deck=(constants.PERMAS, constants.ABAQUS),
                        keyword='DISLOADS TEMPFILM',
                        filename=actions_callback_file, function_name='action')
    
    # Add actions in LAMINATE list in ABAQUS deck under Parent Action
    base.AddListAction(action_name='User Action 4', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action',
                        parent_name='Parent Action', parent_icon_name = 'file_open_16.png')

    # Add actions in LAMINATE list in ABAQUS deck under Parent Action:Child Action
    base.AddListAction(action_name='User Action 4.1', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action',
                        parent_name='Parent Action:Child Action',
                        icon_name='filter_16.png',
                        parent_icon_name='file_open_16.png:file_save_16.png')

    base.AddListAction(action_name='User Action 4.2', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action',
                        parent_name='Parent Action:Child Action')

    # Add actions in LAMINATE list in ABAQUS deck under Parent Action
    base.AddListAction(action_name='User Action 5', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='action',
                        parent_name='Parent Action')
    
    # Add action in SHELL_SECTION list in ABAQUS deck
    base.AddListAction(action_name='User Action 6', deck=constants.ABAQUS, keyword='SHELL_SECTION',
                        filename=actions_callback_file, function_name='action')

    # Add action in all property types in PROPERTIES list in ABAQUS deck
    base.AddListAction(action_name='User Action 7', deck=constants.ABAQUS, keyword='PROPERTY',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP)

    # Add action in PROPERTIES list in ABAQUS deck
    base.AddListAction(action_name='User Action 8', deck=constants.ABAQUS, keyword='PROPERTY',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP_ONLY)

    # Add action in all initial conditions in INITIAL CONDITION list in ABAQUS deck
    base.AddListAction(action_name='User Action 9', deck=constants.ABAQUS, keyword='INITIAL CONDITION',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP)

    # Add action in INITIAL CONDITION list in ABAQUS deck
    base.AddListAction(action_name='User Action 10', deck=constants.ABAQUS, keyword='INITIAL CONDITION',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP_ONLY)

    # Add action in SHELL and QUAD list in ABAQUS deck
    base.AddListAction(action_name='User Action 11', deck=constants.ABAQUS, keyword='SHELL',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP)

    # Add action in SHELL list in ABAQUS deck
    base.AddListAction(action_name='User Action 12', deck=constants.ABAQUS, keyword='SHELL',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP_ONLY)

    # Add action in ELEMENT and QUAD list in ABAQUS deck
    base.AddListAction(action_name='User Action 13', deck=constants.ABAQUS, keyword='ELEMENT',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP_ELEMENT)

    # Add action in ELEMENT list in ABAQUS deck
    base.AddListAction(action_name='User Action 14', deck=constants.ABAQUS, keyword='ELEMENT',
                        filename=actions_callback_file, function_name='action',
                        group=constants.LIST_ACTION_IN_GROUP_ELEMENT_ONLY)

    # Add action in LAMINATE list in ABAQUS deck which raises a window
    base.AddListAction(action_name='User Action 15', deck=constants.ABAQUS, keyword='LAMINATE',
                        filename=actions_callback_file, function_name='window',
                        separator=True)

if __name__ == '__main__':
    main()

