import ansa
from ansa import guitk


def action(deck, entities, alist, *args):
    print('Deck:', deck)
    print('Number of selected entities:', alist.selected)
    print('Number of total entities in list:', alist.total)

    # Print the ids of the selected entities
    for ent in entities:
        print(ent._id)


def window(deck, entities, alist, *args):
	win = guitk.BCWindowCreate("BCWindow Example", guitk.constants.BCOnExitDestroy)
	guitk.BCWindowShowTitleBarButtons(win, guitk.constants.BCMinimizeButton | guitk.constants.BCMaximizeButton)

	guitk.BCPushButtonCreate(win, "Flash", flashWindowFunc, win)
	dbb = guitk.BCDialogButtonBoxCreate(win)

	guitk.BCWindowSetInitSize(win, 240, 160)
	guitk.BCWindowSetSaveSettings(win, False)

	guitk.BCWindowSetAcceptFunction(win, acceptFunc, None)
	guitk.BCWindowSetRejectFunction(win, rejectFunc, None)

	guitk.BCShow(win)

def flashWindowFunc(b, win):
	guitk.BCWindowFlash(win)
	return 0

def acceptFunc(win, data):
	print("Accept")
	return 1

def rejectFunc(win, data):
	print("Reject")
	return 1

