from ansa import base
from ansa import constants

def _get_values_from_source_mat(source_mat: base.Entity, data: list, verbose: bool) -> str:
    if not base.GetEntityType(constants.ABAQUS, source_mat):
        if verbose: print('ABAQUS MATERIAL is needed!')
        return ''
    
    fields = ('Elasticity', '*ELASTIC', 'DEP_ELAST', 'ELASTIC_TYPE', 'E1', 'E2', 'v12',
              '*HYPERELASTIC', 'method hyperel', 'POISSON', 'C10', 'C01', 'D1')
    ret_fields = base.GetEntityCardValues(constants.ABAQUS, source_mat, fields)
    target_mat_type = ret_fields['Elasticity'].strip()
    
    if target_mat_type == 'ELASTIC':
        if ret_fields['*ELASTIC'].strip() == 'YES':
            if ret_fields['DEP_ELAST'].strip() == 'NO' and ret_fields['ELASTIC_TYPE'].strip() == 'ENG CONST':
                if ret_fields['E1'] and ret_fields['E2'] and ret_fields['v12']:
                    data.append(ret_fields['E1'])
                    data.append(ret_fields['E2'])
                    data.append(ret_fields['v12'])
                    target_mat_type = 'ORTHOTROPIC'
                else:
                    if verbose: print('Missing data (e.g E2, v12).')
                    return ''
            elif ret_fields['ELASTIC_TYPE'].strip() == 'ISOTROPIC':
                target_mat_type = 'ISOTROPIC'
                if ret_fields['DEP_ELAST'].strip() == 'YES':
                    if verbose: print('Please check if the script supports DEPENDENCY DATA TABLE')
                    return ''
            else:
                if verbose: print('Please check if the script supports the current ELASTIC_TYPE')
                return ''
        else:
            if verbose: print("Use material with *ELASTIC = YES")
            return ''
    elif target_mat_type == 'HYPERELASTIC' and ret_fields['*HYPERELASTIC'].strip() == 'YES':
        if ret_fields['method hyperel'].strip() == 'MOONEY-RIVLIN':
            data.append(ret_fields['POISSON'])
            data.append(ret_fields['C10'])
            data.append(ret_fields['C01'])
        else:
            if verbose: print('Missing data (e.g C10, C01).')
            return ''
    else:
        if verbose: print('Use material with proper Elasticity type')
        return ''
    
    return target_mat_type

def map_fun(source_mat: base.Entity, target_deck: int, *args, **kwargs) -> str:
    src_type_abaqus = base.GetEntityType(constants.ABAQUS, source_mat)
    if src_type_abaqus != "MATERIAL":
        return ""
        
    data = []
    verbose = True
    target_mat_type = _get_values_from_source_mat(source_mat, data, verbose)
    if not target_mat_type:
        if verbose: print("Check the data of the source material")
        return ""
        
    if target_deck != constants.LSDYNA:
        if verbose: print("No proper taget deck found. Update the script properly.")
        return ""
        
    if target_mat_type == 'ORTHOTROPIC':
        return "MAT2O MAT_ORTHOTROPIC_ELASTIC"
    elif target_mat_type == 'HYPERELASTIC':
        return "MAT27 MAT_MOONEY-RIVLIN_RUBBER"
    else:
        return "MAT1 MAT_ELASTIC"

def _set_values_to_target_mat(source_mat: base.Entity, target_mat: base.Entity, data: list, verbose: bool) -> None:
    # Setup the LSDYNA material
    target_deck = constants.LSDYNA
    target_mat_type = base.GetEntityType(target_deck, target_mat)
    if target_mat_type == "MAT1 MAT_ELASTIC":
        mat_vals = {'Name': source_mat._name}
    elif target_mat_type == "MAT2O MAT_ORTHOTROPIC_ELASTIC":
        mat_vals = {'Name': source_mat._name,
                    'EB': data[1],
                    'PRBA': data[2]}
    elif target_mat_type == "MAT27 MAT_MOONEY-RIVLIN_RUBBER":
        mat_vals = {'Name': source_mat._name,
                    'PR': data[0],
                    'A': data[1],
                    'B': data[2]}
    else:
        if verbose: print("Please select LSDYNA deck!")
        return
    
    target_mat.set_entity_values(target_deck, mat_vals)

def sync(source_mat: base.Entity, target_mat: base.Entity, *args, **kwargs) -> None:
    data = []
    verbose = False
    status = _get_values_from_source_mat(source_mat, data, verbose)
    if status:
        _set_values_to_target_mat(source_mat, target_mat, data, verbose)
        if verbose: print('Material mapping succeeded')
    else:
        if verbose: print('Material could not be translated!')
