#ifndef _KINETICS_C_UTILS_H_
#define _KINETICS_C_UTILS_H_


#ifdef WIN32
#define DLL_PUBLIC __declspec(dllexport)
#define DLL_IMPORT __declspec(dllimport)
#endif

#if __GNUC__ >= 4
#define DLL_PUBLIC __attribute__ ((visibility("default")))
#define DLL_IMPORT
#endif

#ifndef DLL_PUBLIC
#define DLL_PUBLIC
#endif

#ifndef DLL_IMPORT
#define DLL_IMPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

/*-------------------------- User Defined Subroutines --------------------------*/

/*
 * GSE             ---------------------------------------------------------------
 */
 
struct sAnsaGSE
{
   int ID;
   int NPAR;
   const double* PAR;
   int NI;
   int NO;
   int U;
   int Y;
   int NS;
   int X;
   int IC;
   int STATIC_HOLD;
   int IMPLICIT;
   int STATICS_ONLY;
   int ND;
   int XD;
   int ICD;
   double SAMPLE_OFFSET;
};

/*!
 * \fn void Gse_deriv( const struct sAnsaGSE* gse, double time, int dflag, int iflag, int ns, double* x_dot )
 * \brief defines the continuous function fc().           
 *
 * \param gse    an object that contains informations for gse element
 * \param time   the current simulation time
 * \param dflag  should be ignored
 * \param iflag  indicates why the routine is being called
 * \param ns     the number of continuous states in gse
 * \param x_dot  an array that contains the return values (the derivatives of the state xc)
 * \return  -
 */
typedef void ansa_c_Gsederiv( const struct sAnsaGSE* gse, double time, int dflag, int iflag, int ns, double* x_dot );
DLL_PUBLIC ansa_c_Gsederiv Gse_deriv;

/*!
 * \fn void Gse_output( const struct sAnsaGSE* gse, double time, int dflag, int iflag, int no, double* y  )
 * \brief defines the continuous function g().           
 *
 * \param gse    an object that contains informations for gse element
 * \param time   the current simulation time
 * \param dflag  should be ignored
 * \param iflag  indicates why the routine is being called
 * \param no     the number of outputs in the gse
 * \param y      an array that contains the return values
 * \return  -
 */
typedef void ansa_c_Gseoutput( const struct sAnsaGSE* gse, double time, int dflag, int iflag, int no, double* y );
DLL_PUBLIC ansa_c_Gseoutput Gse_output;

/*
 *   SFORCE        --------------------------------------------------------------
 */
 
struct sAnsaSforce
{
   int ID;
   int NPAR;
   const double* PAR;
   int I;
   int J;
   int ACTION_ONLY;
   const char* Type;
};

/*!
 * \fn void Sfosub( const struct sAnsaSforce* sforce, double time, int dflag, int iflag, double* result )
 * \brief computes the force magnitude for an SFORCE statement.           
 *
 * \param sforce  an object that contains informations for sforce statement
 * \param time    the current simulation time
 * \param dflag   should be ignored (not supported yet)
 * \param iflag   indicates why the routine is being called
 * \param result  an array that contains the return value
 * \return  -
 */
typedef void ansa_c_Sfosub( const struct sAnsaSforce* sforce, double time, int dflag, int iflag, double* result );
DLL_PUBLIC ansa_c_Sfosub Sfosub;

/*
 *   VFORCE        --------------------------------------------------------------
 */
 
struct sAnsaVforce
{
   int ID;
   int NPAR;
   const double* PAR;
   int I;
   int JFLOAT;
   int RM;
};

/*!
 * \fn void Vfosub( const struct sAnsaVforce* vforce, double time, int dflag, int iflag, double* result )
 * \brief computes force components for a VFORCE statement.           
 *
 * \param vforce  an object that contains informations for vforce statement
 * \param time    the current simulation time
 * \param dflag   should be ignored (not supported yet)
 * \param iflag   indicates why the routine is being called
 * \param result  an array that contains the three return values
 * \return  -
 */
typedef void ansa_c_Vfosub( const struct sAnsaVforce* vforce, double time, int dflag, int iflag, double* result );
DLL_PUBLIC ansa_c_Vfosub Vfosub;

/*
 *   VTORQUE        --------------------------------------------------------------
 */

struct sAnsaVtorque
{
   int ID;
   int NPAR;
   const double* PAR;
   int I;
   int JFLOAT;
   int RM;
};

/*!
 * \fn void Vtosub( const struct sAnsaVtorque* vtorque, double time, int dflag, int iflag, double* result )
 * \brief computes torque components for a VTORQUE statement.           
 *
 * \param vtorque  an object that contains informations for vtorque statement
 * \param time     the current simulation time
 * \param dflag    should be ignored (not supported yet)
 * \param iflag    indicates why the routine is being called
 * \param result   an array that contains the three return values
 * \return  -
 */
typedef void ansa_c_Vtosub( const struct sAnsaVtorque* vtorque, double time, int dflag, int iflag, double* result );
DLL_PUBLIC ansa_c_Vtosub Vtosub;

/*
 *   GFORCE        --------------------------------------------------------------
 */
 
struct sAnsaGforce
{
   int ID;
   int NPAR;
   const double* PAR;
   int I;
   int RM;
   int JFLOAT;
};

/*!
 * \fn void Gfosub( const struct sAnsaGforce* gforce, double time, int dflag, int iflag, double* result )
 * \brief computes a set of six values for a GFORCE statement.           
 *
 * \param gforce  an object that contains informations for gforce statement
 * \param time    the current simulation time
 * \param dflag   should be ignored (not supported yet)
 * \param iflag   indicates why the routine is being called
 * \param result  an array that contains the six return values
 * \return  -
 */
typedef void ansa_c_Gfosub( const struct sAnsaGforce* gforce, double time, int dflag, int iflag, double* result );
DLL_PUBLIC ansa_c_Gfosub Gfosub;

 /*
 *   FIELD         --------------------------------------------------------------
 */
 
struct sAnsaField
{
   int ID;
   int NPAR;
   const double* PAR;
   int I;
   int J;
};

/*!
 * \fn void Fiesub( const struct sAnsaField* fie, double time, double* disp, double* velo, int dflag, int iflag, double* field, double* dfddis, double* dfdvel )
 * \brief computes the force ans torque components for a FIELD statement.           
 *
 * \param fie     an object that contains informations for field statement
 * \param time    the current simulation time
 * \param disp    an array that contains the translational and rotational displacements of the I-marker 
 *                with respect to the J-marker expressed in the coordinate system of J-marker
 * \param velo    an array that contains the translational and rotational velocities of the I-marker 
 *                with respect to the J-marker expressed in the coordinate system of J-marker
 * \param dflag   should be ignored (not supported yet)
 * \param iflag   indicates why the routine is being called
 * \param field   an array that contains the six return field components
 * \param dfddis  an array that contains the return derivatives of the six field components
 *                with respect to the six displacement values in disp array
 * \param dfdvel  an array that contains the return derivatives of the six field components
 *                with respect to the six velocity values in velo array
 * \return  -
 */
typedef void ansa_c_Fiesub( const struct sAnsaField* fie, double time, double* disp, double* velo, int dflag, int iflag, double* field, double* dfddis, double* dfdvel );
DLL_PUBLIC ansa_c_Fiesub Fiesub;

/*---------------------------- Utility Subroutines -----------------------------*/

/*!
 * \fn void c_sysary( const char *fncnam, const int *ipar, int nsize, double *states, int *nstate, int *errflg )
 * \brief provides system state values 
 *
 * \param fncnam  the name of the function to be called
 * \param ipar    an array that contains the parameter list for function fncnam
 * \param nsize   the size of array ipar
 * \param states  an array that contains the return values
 * \param nstate  the size of array states
 * \param errflg  a logical variable that returns as true if error occured
 * \return  -
 */
DLL_IMPORT void c_sysary( const char* fncnam, const int* ipar, int nsize, double* states, int* nstate, int* errflg );

/*!
 * \fn void c_sysfnc( const char *fncnam, const int *ipar, int nsize, double *states, int *errflg )
 * \brief provides a single-system state value 
 *
 * \param fncnam  the name of the function to be called
 * \param ipar    an array that contains the parameter list for function fncnam
 * \param nsize   the size of array ipar
 * \param states  an array that contains the return value
 * \param errflg  a logical variable that returns as true if error occured
 * \return  -
 */
DLL_IMPORT void c_sysfnc( const char* fncnam, const int* ipar, int nsize, double* states, int* errflg );

/*!
 * \fn void c_errmes( int errflg, const char *mesage, int id, const char *endflg )
 * \brief provides the facility for outputting error messages from user-written subroutines
 *
 * \param errflg  a logical variable that is true if error occured
 * \param mesage  a character array with max size 1024, that errmes will document if errflg is true
 * \param id      the id of the statement that is invoking the user-written subroutine
 * \param endflg  a character array that stops execution when it equals to "STOP"
 * \return  -
 */
DLL_IMPORT void c_errmes( int errflg, const char* mesage, int id, const char* endflg );

#ifdef __cplusplus
}
#endif

#endif