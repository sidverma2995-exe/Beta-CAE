#include "kinetics_c_utils.h"


void Gse_deriv( const struct sAnsaGSE* gse, double time, int dflag, int iflag, int ns, double* x_dot )
{
   int arg_x = (int)gse->PAR[0];
   int error_flg = 0;
   int nstate = 0;
   double x[2] = {0.0, 0.0};

   c_sysary( "ARRAY", &arg_x, 1, x, &nstate, &error_flg );
   if(error_flg) 
      c_errmes (error_flg, "Error calling SYSARY for X in gse_deriv",
                gse->ID, "ERROR");

   double x1 = x[0];
   double x2 = x[1];
   
   x_dot[0] = -9.806 - x1 - 100*x2;  
   x_dot[1] = x1;
}

