#include "kinetics_c_utils.h"

void Sfosub(const struct sAnsaSforce* sforce, double time, int dflag, int iflag, double* result)
{
   double d_const = sforce->PAR[0];
   double v_const = sforce->PAR[1];
   
   double dz = 0.0;
   double vz = 0.0;
   int leflag = 0;
   int markers[3] = {5, 4, 4};

   c_sysfnc( "DZ", markers, 3, &dz, &leflag );
   if ( leflag )
   {
	   c_errmes( leflag, "Error: Sfosub: Compute dz", sforce->ID, "error" );
   }

   c_sysfnc( "VZ", markers, 3, &vz, &leflag );
   if ( leflag )
   {
	   c_errmes( leflag, "Error: Sfosub: Compute dz", sforce->ID, "error" );
   }
   
   result[0] = -d_const * (dz-50) -v_const * vz;
}