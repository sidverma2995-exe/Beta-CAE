import sys
import os
dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
path = os.path.join(dir, 'build', 'lib.linux-x86_64-3.11')
if path not in sys.path: sys.path.append(path)
import porch



def test():
	seed_num = (porch.sunflower_seeds(5))
	print(type(seed_num), seed_num )
	coords = porch.rose_function(5, 1)
	print(coords)

	print(porch.plants_colors('rose'))


if __name__ == '__main__':
    test()
