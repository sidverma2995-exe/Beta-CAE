
/*-------------------headers-------------------*/
#include <Python.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
static PyObject *sunflower_seeds(PyObject *self, PyObject *args)
{
	int first = 0, second = 1, next = 0;
	int n, i;

	if (!PyArg_ParseTuple(args, "i:porch.sunflower_seeds", &n)) return NULL;

	if (n < 0) {
		PyErr_SetString(PyExc_ValueError, "porch.sunflower_seeds: Spiral value should be positive or zero!");
		return NULL;
	}

	for (i = 0; i < n; i++) {
		if (i <= 1) {
			next = i;
		} else {
			next = first + second;
			first = second;
			second = next;
		}
	}
	return PyLong_FromLong(next);
} /* sunflower_seeds */


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
static PyObject *rose_function(PyObject *self, PyObject *args, PyObject *kwds)
{
	PyObject	*py_dict = NULL, *py_x_coor = NULL, *py_y_coor = NULL;
	double		t_param = 0;
	int		k_factor = 0;
	double		x_coor, y_coor;
	char		*kwlist[] = {"k_factor", "t_parameter", NULL};

	if (!PyArg_ParseTupleAndKeywords(args, kwds, "id:porch.rose_function", kwlist, &k_factor, &t_param) ) {
	    return NULL;
	}

	x_coor = cos(t_param * k_factor) * cos(t_param);
	y_coor = cos(t_param * k_factor) * sin(t_param);

	py_dict = PyDict_New();

	py_x_coor = PyFloat_FromDouble(x_coor);
	PyDict_SetItemString(py_dict, "x_coordinate", py_x_coor);
	Py_DECREF(py_x_coor);

	py_y_coor = PyFloat_FromDouble(y_coor);
	PyDict_SetItemString(py_dict, "y_coordinate", py_y_coor);
	Py_DECREF(py_y_coor);

	return py_dict;
} /* rose_function */


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
static PyObject *plants_colors(PyObject *self, PyObject *args)
{
	char	*flower_name = NULL;
    	char    msg[32], out_msg[256];

	if (!PyArg_ParseTuple(args, "s:porch.plants_colors", &flower_name)) {
		return NULL;
	}

	if (!strcmp(flower_name, "rose")) {
		sprintf(msg, "red");
	} else if (!strcmp(flower_name, "sunflower")) {
		sprintf(msg, "yellow");
	} else if (!strcmp(flower_name, "olive tree")) {
		sprintf(msg, "green");
	} else if (!strcmp(flower_name, "daisy")) {
		sprintf(msg, "white");
	} else {
		PyErr_SetString(PyExc_ValueError, "porch.plants_colors: invalid flower_name");
		return NULL;
	}

    	sprintf(out_msg, "My porch's %ss are %s",flower_name, msg);

	return PyUnicode_FromString(out_msg);
} /* plants_colors */


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */

static PyMethodDef PorchMethods[] = {
        {
            "sunflower_seeds", sunflower_seeds,
            METH_VARARGS,
            "Calculate the fibonacci number of the seed heads in the main sunflower spiral in the n-th ring."
        },
        {
            "rose_function", (PyCFunction)rose_function,
            METH_KEYWORDS | METH_VARARGS,
            "Calculate the rose function's coordinates, with given parameter ( t ) and factor ( k )."
        },
        {
            "plants_colors", plants_colors,
            METH_VARARGS,
            "Return my porch's plant colors. Input is a plant name (rose, sunflower, olive tree, daisy)"
        },
        { NULL }
};


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
static struct PyModuleDef porch = {
	PyModuleDef_HEAD_INIT,
	"porch",
	NULL, //Documentation
	-1, // Default value in order to keep state in global variables.
	PorchMethods
};


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
PyMODINIT_FUNC PyInit_porch(void)
{
	PyObject *m;

	m = PyModule_Create(&porch);

	return m;
} /* PyInit_fibonacci */


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
