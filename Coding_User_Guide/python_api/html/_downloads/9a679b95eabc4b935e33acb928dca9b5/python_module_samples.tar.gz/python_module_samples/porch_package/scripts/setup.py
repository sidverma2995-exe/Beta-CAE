import sys
from distutils.core import setup, Extension
import distutils.sysconfig
import site
import traceback
import os
import platform
import ansa

sys.argv = [ '', 'build']
python_root_folder = '~/local/'

penv = platform.uname()

def set_environment_flags():
    if penv[0] == 'Linux':
        os.environ['CC'] = 'gcc -pthread'
        os.environ['CXX'] = 'g++'
        os.environ['LDSHARED'] = os.environ['CC'] + ' -shared'

def ret_my_include_path(plat_specific=0, prefix=None):
    if penv[0] == 'Linux':
        include_path = os.path.join(os.path.expanduser(python_root_folder), 'python', 'include', 'python3.11')
    elif penv[0] == 'Windows':
        include_path = os.path.join(python_root_folder, 'Python-3.11.2', 'Include')
    else:
        raise EnvironmentError('ERROR Unknown Operating System.')

    return include_path


def ret_my_lib_path():
    if penv[0] == 'Linux':
        i = ansa.constants.app_root_dir.rfind('ansa_v')
        path = ansa.constants.app_root_dir[:i] + \
                ansa.constants.app_root_dir[i:].replace('ansa_v', 'shared_v')

        lib_path = os.path.join(path, 'python', 'linux64')
    elif penv[0] == 'Windows':
        lib_path = os.path.join(python_root_folder, 'Python-3.11.2', 'PCBuild', 'amd64')
    else:
        raise EnvironmentError('ERROR Unknown Operating System.')

    return lib_path

try:
    dir = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    source_fname = os.path.join(dir, 'src', 'porch.c')

    lib_path = ret_my_lib_path()

    module = Extension('porch',
                include_dirs= [ret_my_include_path],
                library_dirs= [lib_path],
                sources =  [source_fname])

    distutils.sysconfig.get_python_inc = ret_my_include_path

    set_environment_flags()

    setup(name='MyPorchPackage',
            version='1.0',
            description='This is a Sample Python Package',
            author='BETA CAE Systems',
            author_email='ansa@beta-cae.com',
            ext_modules= [module])


except SystemExit as e:
    print("SystemExit: called")
    print(e)
    traceback.print_exc()
