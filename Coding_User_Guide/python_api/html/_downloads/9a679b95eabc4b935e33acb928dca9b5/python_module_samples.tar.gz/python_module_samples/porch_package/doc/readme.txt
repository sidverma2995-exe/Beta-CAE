==================================================================
            	Porch Python Package
            author: BETA CAE Systems
            author_email: ansa@beta-cae.com
==================================================================

	This package is using Python 3.11.2.

NOTE: 	In order for this package to be used the developer source files of Python 3.11.2 are needed.
		From these source files Python 3.11.2 should be compiled and installed into your system.

How to Compile Python.

	- Download the source files of Python 3.11.2 from http://www.python.org.
	- Extract the Python source in your local directory (for example we choose C:/src/).
	  In our example this directory will be called python_root_folder

	  You should have a directory named '/python_root_folder/Python-3.11.2/'.

	Linux:
		In the above directory simply run:
		./configure
		make
		make install.

		Detailed instructions on how to build CPython yourself can be found in
		'https://docs.python.org/3.11/using/unix.html'


	Windows:
		Locate the pcbuild.sln file inside the '/python_root_folder/Python-3.11.2/PCBuild' directory.
		Open this file using Visual Studio 2017.
		Preferably change the build mode to 'Release'.
		Compile the project (key shortcut F7).

		The '/python_root_folder/Python-3.11.2/PCBuild' directory should now have all the desired files.

		After doing this you should copy pyconfig.h inside your '/python_root_folder/Python-3.11.2/Include' directory.

		This file can be found inside
		'/python_root_folder/Python-3.11.2/PC/' directory.

		Detailed instructions on how to build CPython yourself can be found in
		'https://docs.python.org/3.11/using/windows.html'


Setting Up the package scripts for setup.

	- First of all the file /python_module_samples/porch_package/scripts/setup.py must be edited.
	  The variable 'python_root_folder' should be changed to point to the
	  directory were you extracted or installed the python code.

	  Also, you should change the ret_my_lib_path() and ret_my_include_path() functions to point to the correct directories

	- ret_my_lib_path() should point to the directory that contains the python library files
	  In Linux this directory is '<Ansa Instalation Root Folder>/shared_v24.0.0/python/linux64/'
	  In Windows this directory is '/python_root_folder/Python-3.11.2/PCBuild/amd64'.

	- ret_my_include_path() should point to the directory that contains the pyconfig.h file.
	  In Linux this directory is '/python_root_folder/python/include/python3.11/'
	  In Windows this directory is '/python_root_folder/Python-3.11.2/Include/'.


Running the package setup.

	- Go to /python_module_samples/porch_package/ directory.

	- Inside this directory run the command:
		Linux:  <Ansa Instalation Root Folder>/ansa_v24.0.0/ansa64.sh -exec load_script:scripts/setup.py -nogui
	  	Windows: <Ansa Instalation Root Folder>/ansa_v24.0.0/ansa64.bat -exec load_script:scripts/setup.py -nogui

	  This will compile the source code and create a directory named 'build'
	  This directory contains a directory named 'lib.linux-x86_64-3.11', in linux, or a directory 'named lib.win-amd64-3.11' in windows.

	  In this directory, the compiled python module 'porch' is stored.


Running the package.

	- Inside the same directory edit the /scripts/run.py file.

	- Change the command : 'path = os.path.join(dir, 'build', 'lib.linux-x86_64-3.11')'
	  in order to point to the correct directory according to your Operating System.
	  The correct directory is the derivative of setup.py execution.

	- Finally open the script run.py inside Ansa and run it.
	  In this file the usage of the module is depicted.
