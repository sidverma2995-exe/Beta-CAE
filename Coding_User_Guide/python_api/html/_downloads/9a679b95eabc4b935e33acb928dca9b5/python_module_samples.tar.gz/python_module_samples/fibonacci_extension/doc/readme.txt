==================================================================
            Fibonacci Python CTYPE extension.
            author: BETA CAE Systems
            author_email: ansa@beta-cae.com
==================================================================

	This module is using Python 3.11.2.

NOTE: 	In order for this module to be used the developer source files of Python 3.11.2 are needed.
		From these source files Python 3.11.2 should be compiled and installed into your system.

How to Compile Python.

	- Download the source files of Python 3.11.2 from http://www.python.org.
	- Extract the Python source in your local directory (for example we choose C:/src/).
	  In our example this directory will be called python_root_folder

	  You should have a directory named '/python_root_folder/Python-3.11.2/'.

	Linux:
		In the above directory simply run:
		./configure
		make
		make install.

		Detailed instructions on how to build CPython yourself can be found in
		'https://docs.python.org/3.11/using/unix.html'

	Windows:
		Locate the pcbuild.sln file inside the '/python_root_folder/Python-3.11.2/PCBuild' directory.
		Open this file using Visual Studio 2017.
		Preferably change the build mode to 'Release'.
		Compile the project (key shortcut F7).

		The '/python_root_folder/Python-3.11.2/PCBuild' directory should now have all the desired files.

		After doing this you should copy pyconfig.h inside your '/python_root_folder/Python-3.11.2/Include' directory.

		This file can be found inside '/python_root_folder/Python-3.11.2/PC/' directory.

		Detailed instructions on how to build CPython yourself can be found in
		'https://docs.python.org/3.11/using/windows.html'

In order to use this module.

Compiling the module.
	First of all inside the directory /python_module_samples/fibonacci_extension/
	create a directory named 'build'.

	Linux:
		- Inside the /python_module_samples/fibonacci_extension/build/ directory run the command:
			'cmake ../src'
		  This will create all the required Makefiles for the compilation.

		- Inside the same build directory run the 'make' command.
		  this will create the library object 'libfibonacci_c_library.so'

	Windows:
		- Inside the /python_module_samples/fibonacci_extension/build/ directory run the command:
			cmake -G "Visual Studio 15 2017 Win64" ../src/
		  This will create all the required files for the compile.

		- Open in your file browser the directory build/ (you can simple
		  type start. in command prompt while inside it)

		- In this directory locate the file fibonacci_cproject. Open it
		  with Visual Studio 2017.

		- Right click on fibonacci_c_library project directory and select
		  "Set As StartUp Project".

		- Select 'Release' as solution configuration
		  and 'x64' as Solution Platforms

		- build the project (Shortcut F7).

		- This procedure will create the fibonacci_c_library.dll inside directory /build/Release.

Run the module.
	Linux:
		- Launch ansa_v24.0.0 in the script editor open file:
		  	/python_module_samples/fibonacci_extension/scripts/run_unix.py
		  This file depicts the import of the newly created module.

		  Finally execute this file.

	Windows:
		- Launch ansa_v24.0.0 in the script editor open file:
		  	/python_module_samples/fibonacci_extension/scripts/run_win.py
		  This file depicts the import of the newly created module.

		  Finally execute this file.
