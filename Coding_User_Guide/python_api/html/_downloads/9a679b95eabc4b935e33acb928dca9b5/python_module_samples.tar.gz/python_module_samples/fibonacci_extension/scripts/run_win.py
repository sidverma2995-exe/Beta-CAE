#!/usr/bin/python
import ctypes
import os

def main():
    d = os.path.dirname(os.path.dirname(os.path.realpath(__file__)))
    library_path = os.path.join(d, 'build', 'Release', 'fibonacci_c_library.dll')
    lib = ctypes.cdll.LoadLibrary(library_path)

    restype = ctypes.c_int
    argtypes = [ ctypes.c_int ]
    fibonacci_prototype = ctypes.CFUNCTYPE(restype, *argtypes)
    fibonacci_function = fibonacci_prototype(lib.Fibonacci)

    term = 10
    nf = fibonacci_function(term)
    print('The {}th Fibonacci number is {}'.format(term, nf))


if __name__ == '__main__':
    main()
