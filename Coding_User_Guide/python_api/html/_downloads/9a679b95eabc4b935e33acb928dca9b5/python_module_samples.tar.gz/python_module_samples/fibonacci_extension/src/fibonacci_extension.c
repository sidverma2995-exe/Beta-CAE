
/*-------------------headers-------------------*/

#include <stdio.h>

#ifdef _WIN32
#define DllExport __declspec( dllexport )
#else
#define DllExport
#endif

DllExport int Fibonacci(int n)
{
	int i = 0;
	int first = 0, second = 1, next = 0;

	for (i = 0; i < n; i++) {
		if (i <= 1) {
			next = i;
		} else {
			next = first + second;
			first = second;
			second = next;
		}
	}
	return next;
} /* Fibonacci */


/* --------------------------------------------------------------------------------------------------------- */

/* --------------------------------------------------------------------------------------------------------- */
